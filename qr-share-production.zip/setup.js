require("dotenv").config();
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const fs = require("fs");

(async () => {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });
  await pool.query(fs.readFileSync("schema.sql", "utf8"));

  const accounts = [
    ["admin", process.env.ADMIN_USERNAME, process.env.ADMIN_PASSWORD],
    ["user", process.env.USER_USERNAME, process.env.USER_PASSWORD]
  ];

  for (const [role, username, password] of accounts) {
    if (!username || !password || password.length < 12) throw new Error(`${role} credentials missing or password is shorter than 12 characters.`);
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO users(username,password_hash,role) VALUES($1,$2,$3)
       ON CONFLICT(username) DO UPDATE SET password_hash=EXCLUDED.password_hash, role=EXCLUDED.role`,
      [username, hash, role]
    );
  }
  console.log("Database schema and accounts initialized.");
  await pool.end();
})().catch(e => { console.error(e); process.exit(1); });
