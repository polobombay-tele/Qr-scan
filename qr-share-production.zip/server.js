require("dotenv").config();

const express = require("express");
const http = require("http");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const crypto = require("crypto");
const { Server } = require("socket.io");
const { S3Client, PutObjectCommand, DeleteObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });

const PORT = Number(process.env.PORT || 3000);
const BUCKET = process.env.S3_BUCKET;
const publicBase = (process.env.S3_PUBLIC_BASE_URL || "").replace(/\/$/, "");

if (!process.env.DATABASE_URL || !process.env.SESSION_SECRET || !BUCKET) {
  console.error("Missing DATABASE_URL, SESSION_SECRET or S3_BUCKET.");
  process.exit(1);
}

const s3 = new S3Client({
  region: process.env.S3_REGION || "auto",
  endpoint: process.env.S3_ENDPOINT || undefined,
  forcePathStyle: false,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY
  }
});

app.set("trust proxy", 1);
app.use(helmet({
  crossOriginResourcePolicy: { policy: "cross-origin" },
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "https:", "wss:"],
      styleSrc: ["'self'", "'unsafe-inline'"]
    }
  }
}));
app.use(express.json({ limit: "100kb" }));

const sessionMiddleware = session({
  store: new pgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 8 * 60 * 60 * 1000
  }
});
app.use(sessionMiddleware);

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many login attempts. Try again later." }
});

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => cb(null, /^image\\/(jpeg|png|webp|gif)$/.test(file.mimetype))
});

function auth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Login required" });
  next();
}
function adminOnly(req, res, next) {
  if (req.session.role !== "admin") return res.status(403).json({ error: "Admin only" });
  next();
}
function publicUrl(key) {
  return publicBase ? `${publicBase}/${key}` : null;
}

app.post("/api/login", loginLimiter, async (req, res) => {
  try {
    const username = String(req.body.username || "").trim();
    const password = String(req.body.password || "");
    if (!username || !password) return res.status(400).json({ error: "Username and password are required." });

    const { rows } = await pool.query("SELECT id, username, password_hash, role FROM users WHERE username=$1", [username]);
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Invalid username or password." });
    }

    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.role = user.role;
    res.json({ ok: true, username: user.username, role: user.role });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Login failed." });
  }
});

app.post("/api/logout", auth, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  res.json({ loggedIn: !!req.session.userId, username: req.session.username || null, role: req.session.role || null });
});

app.get("/api/latest", auth, async (req, res) => {
  const { rows } = await pool.query(
    "SELECT id, original_name, mime_type, size_bytes, decoded_text, created_at, object_key FROM qr_items ORDER BY created_at DESC LIMIT 1"
  );
  const item = rows[0];
  if (!item) return res.json(null);
  // Do not expose storage credentials. The public URL is only returned if configured.
  item.imageUrl = publicUrl(item.object_key);
  res.json(item);
});

app.post("/api/upload", auth, adminOnly, upload.single("qr"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Please upload a JPG, PNG, WEBP or GIF image." });

    const id = crypto.randomUUID();
    const ext = ({ "image/jpeg":"jpg", "image/png":"png", "image/webp":"webp", "image/gif":"gif" })[req.file.mimetype] || "bin";
    const key = `qr/${new Date().toISOString().slice(0,10)}/${id}.${ext}`;

    await s3.send(new PutObjectCommand({
      Bucket: BUCKET,
      Key: key,
      Body: req.file.buffer,
      ContentType: req.file.mimetype,
      CacheControl: "public,max-age=31536000,immutable"
    }));

    // The decoded value is intentionally supplied by the browser, not trusted for authorization.
    const decoded = typeof req.body.decodedText === "string" ? req.body.decodedText.slice(0, 4000) : null;

    const { rows } = await pool.query(
      `INSERT INTO qr_items(id, object_key, original_name, mime_type, size_bytes, decoded_text, created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7)
       RETURNING id, original_name, mime_type, size_bytes, decoded_text, created_at, object_key`,
      [id, key, req.file.originalname.slice(0,255), req.file.mimetype, req.file.size, decoded, req.session.userId]
    );

    const item = rows[0];
    item.imageUrl = publicUrl(item.object_key);
    io.to("user").emit("qr:new", item);
    res.json({ ok: true, item });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Upload failed." });
  }
});

// Optional private-storage mode: if S3_PUBLIC_BASE_URL is not set, stream the image
// through this authenticated endpoint instead.
app.get("/api/qr/:id/image", auth, async (req, res) => {
  try {
    const { rows } = await pool.query("SELECT object_key, mime_type FROM qr_items WHERE id=$1", [req.params.id]);
    if (!rows[0]) return res.sendStatus(404);
    const obj = await s3.send(new GetObjectCommand({ Bucket: BUCKET, Key: rows[0].object_key }));
    res.setHeader("Content-Type", rows[0].mime_type);
    res.setHeader("Cache-Control", "private, max-age=3600");
    obj.Body.pipe(res);
  } catch (e) {
    console.error(e);
    res.sendStatus(404);
  }
});

io.use((socket, next) => sessionMiddleware(socket.request, {}, next));
io.use((socket, next) => {
  const s = socket.request.session;
  if (!s || !s.userId) return next(new Error("Unauthorized"));
  next();
});
io.on("connection", socket => {
  const s = socket.request.session;
  if (s.role === "user") socket.join("user");
});

app.use(express.static("public"));
app.get("*", (req, res) => res.sendFile(require("path").join(__dirname, "public/index.html")));

server.listen(PORT, () => console.log(`QR Share production server listening on :${PORT}`));
