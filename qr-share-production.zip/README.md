# QR Share — Production-ready foundation

## Architecture
- Node.js + Express
- PostgreSQL for users, sessions and QR metadata
- bcrypt password hashing
- `express-session` backed by PostgreSQL
- Helmet security headers
- Login rate limiting
- S3-compatible object storage for permanent QR images
- Socket.IO for real-time admin → user delivery
- One admin account + one user account by default
- Browser-side QR decoding with jsQR

## Setup
1. Create a PostgreSQL database.
2. Create an S3-compatible bucket (Cloudflare R2, AWS S3, Supabase Storage via an S3-compatible gateway, etc.).
3. Copy `.env.example` to `.env`.
4. Set strong credentials and storage/database values.
5. Install:
   `npm install`
6. Initialize:
   `node setup.js`
7. Start:
   `npm start`

For production, put the app behind HTTPS/reverse proxy and set:
`NODE_ENV=production`

### Private storage
If `S3_PUBLIC_BASE_URL` is empty, the app serves QR images through `/api/qr/:id/image` after authentication. This keeps the bucket private.

### Public storage
If you set `S3_PUBLIC_BASE_URL` to a CDN/public bucket URL, uploaded QR images are displayed using that URL. Do not use this mode if the QR contents are sensitive.

## Important security notes
- Never commit `.env`.
- Use a unique 64+ character `SESSION_SECRET`.
- Use long, unique passwords (12+ characters; preferably 16+).
- Restrict the storage bucket's write permissions to the application's access key.
- Enable HTTPS.
- Keep PostgreSQL and object storage credentials server-side only.
- Rotate credentials if exposed.
- QR decoding is for displaying/processing QR data; it does not authorize or bypass an ATM/payment system.

## Production hardening you may add
- 2FA/WebAuthn for admin
- CSRF tokens for state-changing browser requests
- audit log table
- multiple users with per-user routing
- signed, expiring object URLs
- antivirus/content scanning for uploads
- image re-encoding to strip metadata
- backup/retention policy
- monitoring and alerting
